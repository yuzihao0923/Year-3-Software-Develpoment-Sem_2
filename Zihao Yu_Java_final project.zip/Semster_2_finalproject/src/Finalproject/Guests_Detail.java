package Finalproject;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Guests_Detail {
	
	private mainpage mymainpage;
	
	String Date,Name,Phone,Number,Room;
	
	//String[] detail = { Date, Name, Phone, Number, Room };
	
	private DefaultTableModel model;
	private JTable myTable;
	
	public Guests_Detail() {
		JFrame frame = new JFrame();
		frame.setTitle("JFrame Example");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());

		
		model = new DefaultTableModel(); 
		myTable = new JTable(model);
		
		// Create the columns 
		model.addColumn("Date"); 
		model.addColumn("Name");
		model.addColumn("Phone");
		model.addColumn("Number of Guests");
		model.addColumn("Room");
		
		
		
		JScrollPane scroll = new JScrollPane(myTable);
		
		cp.add(scroll);
		
		frame.setSize(600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
	public void setdate(Object[] objects) {
		model.addRow(objects);
	}
}
