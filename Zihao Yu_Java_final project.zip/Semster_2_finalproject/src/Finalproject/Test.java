package Finalproject;

import java.io.FileNotFoundException;

public class Test {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Guests_Detail myGuests_Detail = new Guests_Detail();
		mainpage mylogin = new mainpage(myGuests_Detail);
		
		
	}

}
