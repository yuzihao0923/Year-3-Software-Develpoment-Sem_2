package Finalproject;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class mainpage implements ActionListener{

	JPanel backgroundPanel = new JPanel();
	
	private Guests_Detail myGuests_Detail;
	
	private JTextField Field1 = new JTextField(20);
	private JTextField Field2 = new JTextField(20);
	private JTextField Field3 = new JTextField(20);
	private JTextField Field4 = new JTextField(20);
	private JTextField Field5 = new JTextField(20);

	
	JButton clear = new JButton("Clear");
	JButton update = new JButton("Update");
	
	CardLayout cards;
	JPanel cardPanel;
	JPanel firstCard;
	JPanel secondCard;
	JPanel thirdCard;
	JPanel fourthCard;
	
	JButton jButtonsearch = new JButton("Search");
	JTextField serach = new JTextField(20);	
	
	JTextArea jta1 = new JTextArea("", 10, 20);
	
	JMenuItem Staff = new JMenuItem("Staff");
	JMenuItem Guestdetails = new JMenuItem("Guestdetails");
	JMenuItem Search = new JMenuItem("Search");
	JMenuItem Exit = new JMenuItem("Exit");
	
	public mainpage(Guests_Detail myguests_Detail) throws FileNotFoundException{
		JFrame frame = new JFrame();
		frame.setTitle("Software Hotel");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		myGuests_Detail = myguests_Detail;
		
		JMenu Login = new JMenu("Login");

		

		Login.add(Staff);
		Login.add(Guestdetails);
		Login.add(Search);
		Login.add(new JSeparator());
		Login.add(Exit);

		JMenuBar bar = new JMenuBar();
		bar.add(Login);

		Staff.addActionListener(this);
		Guestdetails.addActionListener(this);
		Search.addActionListener(this);
		Exit.addActionListener(this);

		// main page

		ImageIcon icon1 = new ImageIcon("picture\\background1.jpg");
		JLabel imagelabel1 = new JLabel();
		imagelabel1.setIcon(icon1);

		backgroundPanel.add(imagelabel1);

		// cards
		cards = new CardLayout();
		cardPanel = new JPanel();
		cardPanel.setLayout(cards);

		// first card
		firstCard = new JPanel();
		firstCard.setLayout(new BorderLayout());

		JPanel backgroundPanel2 = new JPanel();
		ImageIcon icon2 = new ImageIcon("picture\\background1.jpg");
		JLabel imagelabel2 = new JLabel();
		imagelabel2.setIcon(icon2);

		backgroundPanel2.add(imagelabel2);

		JPanel loginPanel = new JPanel();
		JLabel name = new JLabel("Staff Name: ");
		JTextField namefield = new JTextField(20);
		JLabel password = new JLabel("Password: ");
		JTextField passwordfield = new JTextField(20);
		JButton jButton1 = new JButton("Login");

		loginPanel.add(name);
		loginPanel.add(namefield);
		loginPanel.add(password);
		loginPanel.add(passwordfield);
		loginPanel.add(passwordfield);
		loginPanel.add(passwordfield);
		loginPanel.add(jButton1);

		firstCard.add(backgroundPanel2, BorderLayout.CENTER);
		firstCard.add(loginPanel, BorderLayout.SOUTH);

		// second card
		secondCard = new JPanel();
		secondCard.setLayout(new BorderLayout());
		secondCard.setBackground(Color.yellow);
		secondCard.setBorder(BorderFactory.createTitledBorder("Check in: "));

		JPanel file = new JPanel();
		file.setLayout(new GridLayout(6, 1));

		JPanel Date = new JPanel();
		JLabel file1 = new JLabel("Date:");
		
		Date.add(file1);
		Date.add(Field1);

		JPanel Name = new JPanel();
		JLabel file2 = new JLabel("Name:");
		Name.add(file2);
		Name.add(Field2);

		JPanel Phone = new JPanel();
		JLabel file3 = new JLabel("Telephone Number:");
		Phone.add(file3);
		Phone.add(Field3);

		JPanel Number = new JPanel();
		JLabel file4 = new JLabel("Numbers of guests:");
		Number.add(file4);
		Number.add(Field4);

		JPanel Room = new JPanel();
		JLabel file5 = new JLabel("Room:");
		Room.add(file5);
		Room.add(Field5);

		JPanel BUTTON = new JPanel();

		BUTTON.add(clear);
		BUTTON.add(update);

		clear.addActionListener(this);
		update.addActionListener(this);
		
		
		file.add(Date);
		file.add(Name);
		file.add(Phone);
		file.add(Number);
		file.add(Room);
		file.add(BUTTON);

		secondCard.add(file);



		// third Card
		thirdCard = new JPanel();
		thirdCard.setLayout(new BorderLayout());
		
		JPanel card3 = new JPanel();
		ImageIcon icon3 = new ImageIcon("picture\\bye.jpg");
		JLabel imagelabel3 = new JLabel();
		imagelabel3.setIcon(icon3);

		card3.add(imagelabel3);

		thirdCard.add(card3);
		
		
		//fourth card
		fourthCard = new JPanel();
		fourthCard.setLayout(new BorderLayout());
		
		JPanel detail = new JPanel();
		JLabel nameserach = new JLabel("Name:");
		
		
		jButtonsearch.addActionListener(this);
		
		detail.add(nameserach);
		detail.add(serach);
		detail.add(jButtonsearch);

		
		
		
		fourthCard.add(detail, BorderLayout.NORTH);
		fourthCard.add(jta1, BorderLayout.CENTER);


		cardPanel.add(firstCard, "1");
		cardPanel.add(secondCard, "2");
		cardPanel.add(thirdCard, "3");
		cardPanel.add(fourthCard, "4");

		cardPanel.setVisible(false);

		cp.add(backgroundPanel);
		cp.add(cardPanel);

		frame.setJMenuBar(bar);
		frame.setSize(700, 350);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == Staff) 
		{
			cardPanel.setVisible(true);
			backgroundPanel.setVisible(false);
			cards.show(cardPanel, "1");
		}
		if (e.getSource() == Guestdetails) 
		{
			cardPanel.setVisible(true);
			backgroundPanel.setVisible(false);
			cards.show(cardPanel, "2");
		}
		if (e.getSource() == Exit) 
		{
			cardPanel.setVisible(true);
			backgroundPanel.setVisible(false);
			cards.show(cardPanel, "3");
		}
		if (e.getSource() == Search) 
		{
			cardPanel.setVisible(true);
			backgroundPanel.setVisible(false);
			cards.show(cardPanel, "4");
		}
		
		String msg1 = "";
		
		String date = Field1.getText();
		String name = Field2.getText();
		String phone = Field3.getText();
		String number = Field4.getText();
		String room = Field5.getText();
		
		String msg = "Date: " + Field1.getText() + "  " + "Name: " + Field2.getText() + "  " + "Telephone Number: "
						+ Field3.getText() + "  " + "Number of Guests: " + Field4.getText() + "  " + "Room: " + Field5.getText() + "\n"; 
		
		String msg2 = msg;
		
		if(e.getSource() == update) 
		{
			
 			
			myGuests_Detail.setdate(new Object[]{Field1.getText(), Field2.getText(), Field3.getText(),Field4.getText(),Field5.getText()});
			
			//send msg to txt file
			Scanner scan = new Scanner(System.in);
			
			Scanner in = new Scanner(msg2); 
			
			System.out.print("Output file: "); 
			String outputFileName = scan.nextLine();
			try {
				PrintWriter out = new PrintWriter(outputFileName);
				out.append(msg2);
				out.close();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			in.close();
			
		}
		
		if(e.getSource() == clear) {
			
			Field1.setText(null);
			Field2.setText(null);
			Field3.setText(null);
			Field4.setText(null);
			Field5.setText(null);

		}
		
		if(e.getSource() == jButtonsearch) {
			int count = 0;
			try {
				JFileChooser chooser = new JFileChooser();
				Scanner in = null;
			//	String value = in.next();
				
				if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
					{
					  File selectedFile = chooser.getSelectedFile();
					  in = new Scanner(selectedFile);
					  
					  while (in.hasNext())
					   {
					     String value = in.nextLine();
					     if(value.equals(serach.getText()))
					     {
					    	 count++;
					  
					     }
					     jta1.setText("" + count + "\n" + value);   
					   }
					}
			}
					catch (FileNotFoundException e1) {
				    	   e1.printStackTrace();
			      }
		}
	}
}
	
	


