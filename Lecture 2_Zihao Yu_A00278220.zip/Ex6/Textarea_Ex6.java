package Ex6;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class Textarea_Ex6 {

 JTextArea jta3 = new JTextArea("", 40, 30);
			
			public Textarea_Ex6() {
				JFrame frame = new JFrame();
				frame.setTitle("Zihao Yu");
				
				Container cp = frame.getContentPane();
				cp.setLayout(new BorderLayout());
				
				
				cp.add(jta3);
				
				frame.setSize(300, 400);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
			
			public void set_text(String msg) {
					jta3.setText(msg);
				}
			}

