package Ex6;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Ex5.Book;

public class Invoice_GUI implements ActionListener{

	private Invoice myInvoice;
	private Textarea_Ex6 myTextarea6;
	
	JTextField jTextField1 = new JTextField(20);
	JTextField jTextField2 = new JTextField(20);
	JTextField jTextField3 = new JTextField(20);
	JTextField jTextField4 = new JTextField(20);
	
	JCheckBox checkUpdate = new JCheckBox("Update");
	
	JButton jButton1 = new JButton("Calculate");
	
	public Invoice_GUI(Textarea_Ex6 myTextarea) {
		
		myTextarea6 = myTextarea;
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		
		Box b0 = new Box(BoxLayout.Y_AXIS);
		Box b1 = new Box(BoxLayout.Y_AXIS);
		
		JLabel label1 = new JLabel("Part Number");
		JLabel label2 = new JLabel("Part Description");
		JLabel label3 = new JLabel("Quality");
		JLabel label4 = new JLabel("Price");
		
		

		b0.add(label1);
		b0.add(label2);
		b0.add(label3);
		b0.add(label4);

		
		b1.add(jTextField1);
		b1.add(jTextField2);
		b1.add(jTextField3);
		b1.add(jTextField4);

		
		
		checkUpdate.setSelected(false);
		
		
		jButton1.addActionListener(this);
		
		cp.add(b0);
		cp.add(b1);
		cp.add(checkUpdate);
		cp.add(jButton1);
		
		
		frame.setSize(500, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
}
	public void actionPerformed(ActionEvent e) {
		
		String thepart_number = jTextField1.getText();
		String thepart_description = jTextField2.getText();
		int thequantity_of_the_item_being_purchased = Integer.parseInt(jTextField3.getText());
		double theprice_per_item = Double.parseDouble(jTextField4.getText());
		
//		if(myInvoice == null) 
//		{
//			
//			if(e.getSource() == jButton1) {
//				String msg = "**** Your Order ****" + "\n" + thepart_number + "Hammer" + "\n" + "Part Number" + thepart_description + "\n" + "Price" + theprice_per_item + "\n" + "Total Cost" + theprice_per_item*thequantity_of_the_item_being_purchased;
//				myTextarea6.set_text(msg);
//				
//			}
//			if(checkUpdate.isSelected()) {
//				String msg = "**** Your Order ****" + "\n" + thepart_number + "Hammer" + "\n" + "Part Number" + thepart_description + "\n" + "Price" + theprice_per_item + "\n" + "Total Cost" + theprice_per_item*thequantity_of_the_item_being_purchased;
//				myTextarea6.set_text(msg);
//				myInvoice = new Invoice(thepart_number, thepart_description, thequantity_of_the_item_being_purchased, theprice_per_item);
//			}
//		}else{
//			String msg = "Invoice already created. If you wish to amend this invoice please check the update checkbox";
//		}
		
		if (myInvoice == null) {
			myInvoice = new Invoice(thepart_number, thepart_description, thequantity_of_the_item_being_purchased, theprice_per_item);
			myTextarea6.set_text(myInvoice.getInvoiceAmount());
		} else {
			if(checkUpdate.isSelected()) {
				myInvoice.setPart_description(thepart_description);
				myInvoice.setPart_description(thepart_description);
				myInvoice.setPrice_per_item(theprice_per_item);
				myInvoice.setQuantity_of_the_item_being_purchased(thequantity_of_the_item_being_purchased);
				
				myTextarea6.set_text(myInvoice.getInvoiceAmount());
			} else {
				String msg = "Invoice already created. If you wish to amend this invoice please check the update checkbox";
				myTextarea6.set_text(msg);
			}
			
		}
		
	}
}