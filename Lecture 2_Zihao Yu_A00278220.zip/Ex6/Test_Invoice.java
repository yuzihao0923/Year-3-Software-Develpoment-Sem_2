package Ex6;

import Ex6.Invoice_GUI;
import Ex6.Textarea_Ex6;

public class Test_Invoice {

public static void main(String[] args) {
		
		Textarea_Ex6 myTextarea_Ex6 = new Textarea_Ex6();
		Invoice_GUI myInvoice_GUI = new Invoice_GUI(myTextarea_Ex6);
		
	}
}
