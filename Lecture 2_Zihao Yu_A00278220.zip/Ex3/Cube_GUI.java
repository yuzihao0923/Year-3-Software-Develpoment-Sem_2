
package Ex3;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Cube_GUI implements ActionListener{

	private JTextField side_length;
	private JButton myButton;

	private Textarea myTextarea1;

	private Cube myCube;
	
	public Cube_GUI(Textarea myTextarea) {
		
		myTextarea1 = myTextarea;
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
	
		myCube = null;
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
	
		JLabel side_lengthLabel = new JLabel("side_length ");
		side_length = new JTextField(5);
		
		myButton = new JButton("Calculate");
		myButton.addActionListener(this);

		
		cp.add(side_lengthLabel);
		cp.add(side_length);
		
		cp.add(myButton);
		
		
		frame.setSize(900, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == myButton) {
			if(myCube == null) {
				String msg;
				int theside = Integer.parseInt(side_length.getText());
				
				myCube = new Cube(theside);
//				myCube.displayarea();
//				myCube.displayvolum();
				msg = myCube.displayarea() + "\n" + myCube.displayvolum();
//				myTextarea1.set_text(myCube.displayarea());
//				myTextarea1.set_text1(myCube.displayvolum());
				myTextarea1.set_text1(msg);
				}
			else
				myTextarea1.set_text("Already exists");
				//System.out.println("Already exists");
			
		}
	}
	
	
}
