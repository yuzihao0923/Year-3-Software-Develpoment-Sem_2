package Ex3;

import Ex3.Cube_GUI;
import Ex3.Textarea;

public class Test_Cube{

	public static void main(String[] args) {
		
		Textarea myTextarea = new Textarea();
		Cube_GUI myCube_GUI = new Cube_GUI(myTextarea);
		
	}

}
