package Ex3;

import java.awt.Container;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class Textarea {

	private Cube_GUI Cube1; 
	
	JTextArea jta = new JTextArea("", 40, 30);
	
	public Textarea() {
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		
		cp.add(jta);
		
		frame.setSize(300, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void set_text(String msg1){
		jta.setText(msg1);
	}
	public void set_text1(String msg2){
		jta.setText(msg2);
	}
}
