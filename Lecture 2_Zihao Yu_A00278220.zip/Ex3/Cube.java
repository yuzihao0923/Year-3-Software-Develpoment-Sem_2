package Ex3;

public class Cube{

	 private double length;
	// private Textarea Textarea1;

	 public Cube(double length) {
		super();
		this.length = length;
		
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	
	 
	public String displayarea(){
		String msg1 = "area is: " + 6*length*length;
		return msg1;
	} 
	
	public String displayvolum(){
		String msg2 = "volum is: " + Math.pow(length, 3);
		return msg2;
	}


}
