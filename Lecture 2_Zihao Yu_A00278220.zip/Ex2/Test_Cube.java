package Ex2;

import Ex2.Cube;

public class Test_Cube{

	public static void main(String[] args) {
		
		Cube_GUI myCube_GUI = new Cube_GUI();
		
		
	}

}
