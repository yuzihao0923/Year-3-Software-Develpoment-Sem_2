package Ex2;

public class Cube{

	 private double length;

	 public Cube(double length) {
		super();
		this.length = length;
		
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	
	 
//	public void displayarea(){
//		System.out.println("area is: " + 6*length*length);
//	} 
	
	public String displayarea(){
		String ans = "area is: " + 6*length*length;
		return ans;
	} 
	
	public void displayvolum(){
		System.out.println("volum is: " + Math.pow(length, 3));
	} 
	 
}
