package Ex4;

public class Cube {

	private int number;

	public Cube(int number) {
		super();
		this.number = number;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	
	public String displaygetNumber(){
		String msg = "getNumber: " + number;
		return msg;
		//System.out.println("getNumber: " + number);
	} 
	
	public String displaydoubleNumber(){
		String msg = "doubleNumber: " + number*2;
		return msg;
		//System.out.println("doubleNumber: " + number*2);
	} 
	
	public String displaytripleNumber(){
		String msg = "tripleNumber: " + number*3;
		return msg;
		//System.out.println("tripleNumber: " + number*3);
	} 
	
	public String displaysquareNumber(){
		String msg = "squareNumber: " + Math.pow(number, 2);
		return msg;
		//System.out.println("squareNumber: " + Math.pow(number, 2));
	} 
	
	public String displaycubeNumber(){
		String msg = "cubeNumber: " + Math.pow(number, 3);
		return msg;
		//System.out.println("cubeNumber: " + Math.pow(number, 3));
	} 
}
