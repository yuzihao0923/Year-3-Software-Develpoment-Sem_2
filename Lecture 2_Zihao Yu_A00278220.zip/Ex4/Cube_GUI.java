package Ex4;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Cube_GUI implements ActionListener{
	
	private JTextField Number;
	JButton jButton = new JButton("Calculate");
	
	JCheckBox checkDouble = new JCheckBox("Double");
	JCheckBox checkTriple = new JCheckBox("Triple");
	JCheckBox checkSquare = new JCheckBox("Square");
	JCheckBox checkCube = new JCheckBox("Cube");
	
	
	private Cube myCube;
	private Textarea_Ex4 myTextarea2;
	
	public Cube_GUI(Textarea_Ex4 myTextarea) {
		
		myTextarea2 = myTextarea;
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");

		myCube = null;
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		JLabel label = new JLabel("Number");
		Number = new JTextField(5);


		checkDouble.setSelected(false);
		checkTriple.setSelected(false);
		checkSquare.setSelected(false);
		checkCube.setSelected(false);
				

		
		jButton.addActionListener(this);
	
		
		
		cp.add(label);
		cp.add(Number);
		
		cp.add(checkDouble);
		cp.add(checkTriple);
		cp.add(checkSquare);
		cp.add(checkCube);

		cp.add(jButton);

		frame.setSize(50,400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == jButton) {
			String msg = "";
			int theside = Integer.parseInt(Number.getText());
			
			if(myCube == null) {
				myCube = new Cube(theside);
			} else {
				myCube.setNumber(theside);
			}
				
			if(checkDouble.isSelected() ) {
				msg += (myCube.displaydoubleNumber() + "\n");
			}
			if(checkTriple.isSelected() ) {
				msg += (myCube.displaytripleNumber() + "\n");
			}
			if(checkSquare.isSelected()) {
				msg += (myCube.displaysquareNumber() + "\n");
			}
			if(checkCube.isSelected()) {
				msg += (myCube.displaycubeNumber() + "\n");
			}
			
			myTextarea2.set_text(msg);

				//msg = myCube.displaygetNumber() + "\n" + myCube.displaydoubleNumber() + "\n" + myCube.displaytripleNumber() + "\n" + myCube.displaysquareNumber() + "\n" + myCube.displaycubeNumber();
		}
			}
	}

