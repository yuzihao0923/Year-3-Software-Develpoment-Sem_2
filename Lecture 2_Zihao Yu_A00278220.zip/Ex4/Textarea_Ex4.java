package Ex4;

import java.awt.Container;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class Textarea_Ex4 {
	
	JTextArea jta1 = new JTextArea(" ", 40, 30);
	
	public Textarea_Ex4() {
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		cp.add(jta1);
		
		frame.setSize(300, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void set_text(String msg) {
			jta1.setText(msg);
		}
	}


