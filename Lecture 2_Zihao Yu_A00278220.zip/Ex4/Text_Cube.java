package Ex4;

import Ex4.Cube_GUI;
import Ex4.Textarea_Ex4;

public class Text_Cube {

public static void main(String[] args) {
		
		Textarea_Ex4 myTextarea_Ex4 = new Textarea_Ex4();
		Cube_GUI myCube_GUI = new Cube_GUI(myTextarea_Ex4);
		
	}
}
