package Ex8;

import Ex8.Letter_GUI;
import Ex8.Textarea_Ex8;

public class Test_Letter {

	public static void main(String[] args) {
		
		Textarea_Ex8 myTextarea_Ex8 = new Textarea_Ex8();
		Letter_GUI myLetter_GUI = new Letter_GUI(myTextarea_Ex8);

	}

}
