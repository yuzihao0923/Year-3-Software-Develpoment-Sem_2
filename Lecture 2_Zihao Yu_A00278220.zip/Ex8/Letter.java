package Ex8;

public class Letter {

	private String recipient_name;
	private String sender_name;
	
	private String txt = "";
	
	public Letter(String recipient_name, String sender_name) {
		super();
		this.recipient_name = recipient_name;
		this.sender_name = sender_name;
	}

	public String getRecipient_name() {
		return recipient_name;
	}

	public void setRecipient_name(String recipient_name) {
		this.recipient_name = recipient_name;
	}

	public String getSender_name() {
		return sender_name;
	}

	public void setSender_name(String sender_name) {
		this.sender_name = sender_name;
	}
	
	public String addLine(String line) {
	
		 txt = txt + line + "\n";
		 return "Dear " + recipient_name + "\n\n" + txt + "\n" + "sincerely," + "\n" + sender_name;
	
	}
	

	}

