package Ex7;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class Textarea_Ex7 {

	JTextArea jta4 = new JTextArea("", 40, 30);
	
	public Textarea_Ex7() {
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		cp.add(jta4);
		
		frame.setSize(300, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void set_text(String msg) {
			jta4.setText(msg);
			return;
		}
	}
