package Ex7;

public class Rectangle {

	private double length;
	private double wideth;

	public Rectangle(double length, double wideth) {
		super();

		// if(length < 0 || length >20)
		// this.length = 1;
		// else
		this.length = length;

		this.wideth = wideth;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double thelength) {
		this.length = thelength;
	}

	public double getWideth() {
		return wideth;
	}

	public void setWideth(double thewideth) {
		this.wideth = thewideth;
	}

	public String perimeter() {
		if (length < 0.0 || length > 20) {
			length = 1.0;
		}
		if (wideth < 0.0 || wideth > 20) {
			wideth = 1.0;
		}
		return String.valueOf(2 * (length + wideth));
	}

	public String area() {

		if (length < 0.0 || length > 20) {
			length = 1.0;
		}
		if (wideth < 0.0 || wideth > 20) {
			wideth = 1.0;
		}

		return String.valueOf(length * wideth);
	}
}
