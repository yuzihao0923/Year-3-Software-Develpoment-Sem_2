package Ex7;

import Ex7.Rectangle_GUI;
import Ex7.Textarea_Ex7;

public class Test_Rectangle {

public static void main(String[] args) {
		
		Textarea_Ex7 myTextarea_Ex7 = new Textarea_Ex7();
		Rectangle_GUI myRectangle_GUI = new Rectangle_GUI(myTextarea_Ex7);
		
	}
}
