package Ex7;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Rectangle_GUI implements ActionListener{
	
	private Textarea_Ex7 myTextarea7;
	private Rectangle myRectangle;
	
	private JTextField Length;
	private JTextField Width;

	JCheckBox checkPerimeter = new JCheckBox("Perimeter");
	JCheckBox checkArea = new JCheckBox("Area");
	JCheckBox checkUpdate = new JCheckBox("Update");
	
	JButton jButton = new JButton("Calculate");
	
	public Rectangle_GUI(Textarea_Ex7 myTextarea) {
		
		myTextarea7 = myTextarea;
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		
		Box b0 = new Box(BoxLayout.Y_AXIS);
		Box b1 = new Box(BoxLayout.Y_AXIS);
		Box b2 = new Box(BoxLayout.X_AXIS);
		Box b3 = new Box(BoxLayout.Y_AXIS);


		
		JLabel label1 = new JLabel("Length");
		Length = new JTextField(5);
		JLabel label2 = new JLabel("Width");
		Width = new JTextField(5);
		
		checkPerimeter.setSelected(false);
		checkArea.setSelected(false);
		checkUpdate.setSelected(false);
		
		
		b0.add(label1);
		b0.add(label2);

		b1.add(Length);
		b1.add(Width);
		
		b2.add(b0);
		b2.add(b1);

		b3.add(checkPerimeter);
		b3.add(checkArea);
		b3.add(checkUpdate);
		
		jButton.addActionListener(this);
		
		cp.add(b2);
		cp.add(b3);

		
		cp.add(jButton);
		
		frame.setSize(100, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}

	public void actionPerformed(ActionEvent e) {
		
			String thelength = Length.getText();
			String thewidth = Width.getText();
		
		
		if(thelength != null && thewidth != null) {
			if(e.getSource() == jButton) {
				if(myRectangle == null) {
					myRectangle = new Rectangle(Double.valueOf(thelength),Double.valueOf(thewidth));
					String msg = "New Rectangle Object Created...";
					myTextarea7.set_text(msg);
				}else {
					String msg = "Rectangle already exists..." + "\n";
					if(checkPerimeter.isSelected()) {
						
						 msg += "The Perimeter is " + myRectangle.perimeter() + "\n";
					}
					if(checkArea.isSelected()) {
						msg += "The Area is " + myRectangle.area() + "\n";
					}
						msg += "check update is change to new values!!";
						
						myTextarea7.set_text(msg);
						
				}
				  if(checkUpdate.isSelected()) {
					  myRectangle = new Rectangle(Double.valueOf(thelength),Double.valueOf(thewidth));
						String msg = "Rectangle updated..." + "\n" +
								"The Perimeter is " + myRectangle.perimeter() + "\n" +
								"The Area is " + myRectangle.area() + "\n" ;
								
						myTextarea7.set_text(msg);
				    }
			}
		
		}
	}
}
