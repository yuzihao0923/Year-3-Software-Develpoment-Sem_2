package Ex1;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Date_GUI implements ActionListener{

	private JTextField Day;
	private JTextField Month;
	private JTextField Year;
	
	private JButton myButton;
	
	private Date myDate;
	
	
		public Date_GUI(){
	
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
	
		myDate = null;

		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
	
		JLabel DayLabel = new JLabel("Day ");
		Day = new JTextField(5);
	
		JLabel MonthLabel = new JLabel("Month ");
		Month = new JTextField(5);
	
		JLabel YearLabel = new JLabel("Year ");
		Year = new JTextField(5);
		
		myButton = new JButton("Print");
		myButton.addActionListener(this);

	
		cp.add(DayLabel);
		cp.add(Day);
	
		cp.add(MonthLabel);
		cp.add(Month);
	
		cp.add(YearLabel);
		cp.add(Year);
	
		cp.add(myButton);
	
	frame.setSize(900, 100);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
}
		public void actionPerformed(ActionEvent e) {
			
			if(e.getSource() == myButton) {
				if(myDate == null) {
					int theDay = Integer.parseInt(Day.getText());
					int theMonth = Integer.parseInt(Month.getText());
					int theYear = Integer.parseInt(Year.getText());

					myDate = new Date(theDay, theMonth, theYear);
					myDate.displayDate();	
				}
				else
					System.out.println("Already exists");
			}
			
		}

}

