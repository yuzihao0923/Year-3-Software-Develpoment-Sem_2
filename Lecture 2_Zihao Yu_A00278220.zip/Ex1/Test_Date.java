package Ex1;

import Ex1.Date;

public class Test_Date {
	public static void main(String[] args) {
		
		Date_GUI myDate_GUI = new Date_GUI();
		
	}

}
