package Ex5;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class Textarea_Ex5 {

JTextArea jta2 = new JTextArea("No book created yet..... ", 40, 30);
	
	public Textarea_Ex5() {
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		cp.add(jta2);
		
		frame.setSize(300, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void set_text(String msg) {
			jta2.setText(msg);
		}
	}
