package Ex5;

import Ex5.Book_GUI;
import Ex5.Textarea_Ex5;

public class Text_Book {

public static void main(String[] args) {
		
		Textarea_Ex5 myTextarea_Ex5 = new Textarea_Ex5();
		Book_GUI myBook_GUI = new Book_GUI(myTextarea_Ex5);
		
	}
}
