package Ex5;

public class Book {
	private String name;
	private String ISBN_number;
	private String author_name;
	private String publisher;
	
	
	
	public Book(String name, String iSBN_number, String author_name, String publisher) {
		super();
		this.name = name;
		ISBN_number = iSBN_number;
		this.author_name = author_name;
		this.publisher = publisher;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getISBN_number() {
		return ISBN_number;
	}



	public void setISBN_number(String iSBN_number) {
		ISBN_number = iSBN_number;
	}



	public String getAuthor_name() {
		return author_name;
	}



	public void setAuthor_name(String author_name) {
		this.author_name = author_name;
	}



	public String getPublisher() {
		return publisher;
	}



	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}



	public String setBookInfo(String theName, String theISBN, String theAuthor, String thePublisher){
		String msg = name + "\n" + ISBN_number + "\n" + author_name + "\n" + publisher;
		return msg;
		
		//System.out.println(name + "\n" + ISBN_number + "\n" + author_name + "\n" + publisher);
	}
}

