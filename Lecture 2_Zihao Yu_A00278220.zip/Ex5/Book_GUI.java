package Ex5;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Ex4.Textarea_Ex4;

public class Book_GUI implements ActionListener{
		
	String t1, t2, t3, t4;
	JTextField jTextField1 = new JTextField(t1,20);
	JTextField jTextField2 = new JTextField(t2,20);
	JTextField jTextField3 = new JTextField(t3,20);
	JTextField jTextField4 = new JTextField(t4,20);

	
	JButton jButton1 = new JButton("Create Book");
	JButton jButton2 = new JButton("Get info");

	private Book myBook;
	private Textarea_Ex5 myTextarea3;
	
		public Book_GUI(Textarea_Ex5 myTextarea) {

			myTextarea3 = myTextarea;
			
			JFrame frame = new JFrame();
			frame.setTitle("Zihao Yu");

			Container cp = frame.getContentPane();
			cp.setLayout(new FlowLayout());


			
			JLabel label1 = new JLabel("Name");
			JLabel label2 = new JLabel("ISBN");
			JLabel label3 = new JLabel("Author");
			JLabel label4 = new JLabel("Publisher");
			
			jButton1.addActionListener(this);
			jButton2.addActionListener(this);


			cp.add(label1);
			cp.add(jTextField1);

			cp.add(label2);
			cp.add(jTextField2);

			cp.add(label3);
			cp.add(jTextField3);
			
			cp.add(label4);
			cp.add(jTextField4);

			cp.add(jButton1);
			cp.add(jButton2);

			frame.setSize(400, 100);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setVisible(true);
		}
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == jButton1) {
				String msg1 = "Book created...";
				
				myTextarea3.set_text(msg1);
			}
				
				String theName = jTextField1.getText();
				String theISBN = jTextField2.getText();
				String theAuthor = jTextField3.getText();
				String thePublisher = jTextField4.getText();
			
				
				//long theName = Long.parseLong(jTextField1.getText());
				//long theISBN = Long.parseLong(jTextField2.getText());
				//long theAuthor = Long.parseLong(jTextField3.getText());
				//long thePublisher = Long.parseLong(jTextField4.getText());
			
				if(myBook == null) {
					myBook = new Book(theName, theISBN, theAuthor, thePublisher);
				}else {
					myBook.setBookInfo(theName, theISBN, theAuthor, thePublisher);
				}
				
				if(e.getSource() == jButton2) {
					
					String msg = "";
					msg = myBook.getName() + "\n" + myBook.getISBN_number() + "\n" + myBook.getAuthor_name() + "\n" + myBook.getPublisher();
					myTextarea3.set_text(msg);
				}
				
			
			
		}
		
	}

