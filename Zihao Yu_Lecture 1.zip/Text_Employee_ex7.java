package meLecture_1;

public class Text_Employee_ex7 {

	public static void main(String[] args) {
		
		Employee_ex7 myEmployee1 = new Employee_ex7("Erzhuang", "Gao",200);
		Employee_ex7 myEmployee2 = new Employee_ex7("Zihao", "Yu",-100);

		
		myEmployee1.employee();
		myEmployee2.employee();

	}
}
