package meLecture_1;

public class Rectangle_ex6 {

	private double length;
	private double wideth;
	
	public Rectangle_ex6(double length, double wideth) {
		super();
		
		//if(length < 0 || length >20)
			//this.length = 1;
		//else
		this.length = length;
		
		
		this.wideth = wideth;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWideth() {
		return wideth;
	}

	public void setWideth(double wideth) {
		this.wideth = wideth;
	}
	
	public void perimeter() {
		if(0.0 <= length && length <= 20.0) {
			System.out.println("Perimeter is:" + 2*(length + wideth));
		}
		if(length < 0.0 || length > 20) {
			length = 1.0;
					}
			else {
				length = length;
			}
		if(wideth < 0.0 || wideth > 20) {
			wideth = 1.0;
					}
			else {
				wideth = wideth;
			}
			System.out.println("Perimeter is:" + 2*(length + wideth));
		}
	
	
	public void area() {
		if(0.0 <= length && length <= 20.0) {
			System.out.println("Area is:" + length * wideth);
		}else {
		if(length < 0.0 || length > 20) {
			length = 1.0;
					}
			else {
				length = length;
			}
		if(wideth < 0.0 || wideth > 20) {
			wideth = 1.0;
					}
			else {
				wideth = wideth;
			}
			
			System.out.println("Area is:" + length * wideth);
		}
	}
}
	


