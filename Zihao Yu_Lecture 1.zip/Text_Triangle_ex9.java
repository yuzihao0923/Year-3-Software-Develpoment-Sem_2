package meLecture_1;

public class Text_Triangle_ex9 {
	
	public static void main(String[] args) {
		
		Triangle_ex9 myTriangle = new Triangle_ex9(3,4,5);
		
		System.out.println("a right triangle: " + myTriangle.isRight());
        System.out.println("no two sides are the same length: " + myTriangle.isScalene());
        System.out.println("exactly two sides are the same length: " + myTriangle.isIsosceles());
        System.out.println("all three sides are the same length: " + myTriangle.isEquilateral());
		
	}
}
