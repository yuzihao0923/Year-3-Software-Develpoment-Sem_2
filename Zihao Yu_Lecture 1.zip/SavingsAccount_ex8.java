package meLecture_1;

public class SavingsAccount_ex8 {

	private String objects;
	private double savingsBalance ;
	private static double annualInterestRate;
	
	public SavingsAccount_ex8(String objects,double savingsBalance, double annualInterestRate) {
		super();
		this.objects = objects;
		this.savingsBalance = savingsBalance;
		this.annualInterestRate = annualInterestRate;
	}

	
	public String getObjects() {
		return objects;
	}


	public void setObjects(String objects) {
		this.objects = objects;
	}


	public double getSavingsBalance() {
		return savingsBalance;
	}

	public void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}

	public double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}
	
	public void calculateMonthlyInterest () {
		double MonthlyInterest;
		MonthlyInterest = (savingsBalance * annualInterestRate)/12;
		System.out.println(objects + "\n" + "MonthlyInterest:" + MonthlyInterest);
	}
	
	//public static void modifyInterestRate () {
		//double annualInterestRate2 = 0.05;
		//double savingsBalance2;
		//savingsBalance2 = savingsBalance + MonthlyInterest;
		//annualInterestRate2 = annualInterestRate;
		//System.out.println(objects + "\n" + "MonthlyInterest:" + MonthlyInterest);
	
	}

