package meLecture_1;

public class Test_number_ex3 {

public static void main(String[] args) {
		
		Number_ex3 myNumber = new Number_ex3(5);
		
		
		
		myNumber.displaygetNumber();
		myNumber.displaydoubleNumber();
		myNumber.displaytripleNumber();
		myNumber.displaysquareNumber();
		myNumber.displaycubeNumber();
}
}
