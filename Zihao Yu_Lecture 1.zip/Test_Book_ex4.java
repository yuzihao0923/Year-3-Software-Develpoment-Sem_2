package meLecture_1;

public class Test_Book_ex4 {

public static void main(String[] args) {
		
		Book_ex4 myBook = new Book_ex4("Mechiel","AIT18012022","Stephen","AIT");
		
		
		myBook.getBookInfo();
		
		myBook.setPublisher("TUS");
		
		myBook.getBookInfo();
	}
}

