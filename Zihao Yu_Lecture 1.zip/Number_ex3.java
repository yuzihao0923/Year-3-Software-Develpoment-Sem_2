package meLecture_1;

public class Number_ex3 {

	private int number;

	public Number_ex3(int number) {
		super();
		this.number = number;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	
	public void displaygetNumber(){
		System.out.println("getNumber: " + number);
	} 
	
	public void displaydoubleNumber(){
		System.out.println("doubleNumber: " + number*2);
	} 
	
	public void displaytripleNumber(){
		System.out.println("tripleNumber: " + number*3);
	} 
	
	public void displaysquareNumber(){
		System.out.println("squareNumber: " + Math.pow(number, 2));
	} 
	
	public void displaycubeNumber(){
		System.out.println("cubeNumber: " + Math.pow(number, 3));
	} 
	
}
