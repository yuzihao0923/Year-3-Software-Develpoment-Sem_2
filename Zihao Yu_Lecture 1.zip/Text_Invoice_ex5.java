package meLecture_1;

public class Text_Invoice_ex5 {

public static void main(String[] args) {
		
		Invoice_ex5 myInvoice = new Invoice_ex5("A00278220","Student",20,-1);
		
		
		myInvoice.getInvoiceAmount();
	}
}
