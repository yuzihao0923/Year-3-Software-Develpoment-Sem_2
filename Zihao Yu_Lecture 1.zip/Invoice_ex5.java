package meLecture_1;

public class Invoice_ex5 {

	private String part_number;
	private String part_description;
	private int quantity_of_the_item_being_purchased;
	private double price_per_item;
	
	public Invoice_ex5(String part_number, String part_description, int quantity_of_the_item_being_purchased,
			double price_per_item) {
		super();
		this.part_number = part_number;
		this.part_description = part_description;
		this.quantity_of_the_item_being_purchased = quantity_of_the_item_being_purchased;
		this.price_per_item = price_per_item;
	}

	public String getPart_number() {
		return part_number;
	}

	public void setPart_number(String part_number) {
		this.part_number = part_number;
	}

	public String getPart_description() {
		return part_description;
	}

	public void setPart_description(String part_description) {
		this.part_description = part_description;
	}

	public int getQuantity_of_the_item_being_purchased() {
		return quantity_of_the_item_being_purchased;
	}

	public void setQuantity_of_the_item_being_purchased(int quantity_of_the_item_being_purchased) {
		this.quantity_of_the_item_being_purchased = quantity_of_the_item_being_purchased;
	}

	public double getPrice_per_item() {
		return price_per_item;
	}

	public void setPrice_per_item(double price_per_item) {
		this.price_per_item = price_per_item;
	}
	
	public void getInvoiceAmount() {
		if(price_per_item > 0 && quantity_of_the_item_being_purchased > 0) {
			System.out.println(part_number + "\n" + part_description + "\n" + "invoice amount: " + price_per_item*quantity_of_the_item_being_purchased);
		}
		if(price_per_item <= 0) {
			price_per_item = 0.0;
			System.out.println(part_number + "\n" + part_description + "\n" + "invoice amount: " + price_per_item*quantity_of_the_item_being_purchased);
		}
		if(quantity_of_the_item_being_purchased <= 0) {
			quantity_of_the_item_being_purchased = 0;
			System.out.println(part_number + "\n" + part_description + "\n" + "invoice amount: " + price_per_item*quantity_of_the_item_being_purchased);
		}
	}
}
