package meLecture_1;

public class Text_Rectangle_ex6 {

	public static void main(String[] args) {
		
		Rectangle_ex6 myRectangle = new Rectangle_ex6(-1.0,30.0);
		
		
		myRectangle.perimeter();
		myRectangle.area();

	}
}
