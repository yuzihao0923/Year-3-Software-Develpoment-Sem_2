package meLecture_1;

public class Test_SavingsAccount_ex8 {

public static void main(String[] args) {
		
	
	
		SavingsAccount_ex8 mySavingsAccount1 = new SavingsAccount_ex8("saver1",2000,0.04);
		SavingsAccount_ex8 mySavingsAccount2 = new SavingsAccount_ex8("sever2",3000,0.04);

		
		mySavingsAccount1.calculateMonthlyInterest();
		mySavingsAccount2.calculateMonthlyInterest();

	}
}
