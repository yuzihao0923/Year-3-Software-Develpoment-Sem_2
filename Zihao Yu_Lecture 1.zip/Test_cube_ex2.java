package meLecture_1;

public class Test_cube_ex2 {

	public static void main(String[] args) {
		
		Cube_ex2 myCube = new Cube_ex2(5.5);
		
		
		
		myCube.displayarea();
		myCube.displayvolum();
	}

}
