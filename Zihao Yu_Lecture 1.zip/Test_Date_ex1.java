package meLecture_1;

public class Test_Date_ex1 {
	public static void main(String[] args) {
		
		Date_ex1 myDate = new Date_ex1(10,12,2021);
		
		
		myDate.displayDate();
	}

}
