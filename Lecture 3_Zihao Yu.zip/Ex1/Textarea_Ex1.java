package Ex1;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class Textarea_Ex1 {

	JTextArea jta1 = new JTextArea("", 10, 20);
	
	public Textarea_Ex1() {
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		
		cp.add(jta1);
		
		frame.setSize(300, 250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public void set_text(String msg) {
		jta1.setText(msg);
	}
}
