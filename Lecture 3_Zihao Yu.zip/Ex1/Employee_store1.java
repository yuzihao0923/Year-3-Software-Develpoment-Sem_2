package Ex1;
import java.util.ArrayList;


public class Employee_store1 
{
	private ArrayList <Employee1> Employee1s;
	
	public Employee_store1()
	{
		Employee1s = new ArrayList<Employee1>();    
		
	}

	public void addEmployee(Employee1 e)
	{
		Employee1s.add(e);
	}
	
	public Employee1 getEmployee(int i)
	{
		return Employee1s.get(i);
	}
	
	public void removeEmployee(int i)
	{
		Employee1s.remove(i);
	}
	
	public int getEmployee_StoreSize()
	{
	
		return Employee1s.size();
	}

}
