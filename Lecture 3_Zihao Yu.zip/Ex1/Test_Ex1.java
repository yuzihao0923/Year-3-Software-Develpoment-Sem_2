package Ex1;

import Ex1.Employee_GUI;
import Ex1.Textarea_Ex1;

public class Test_Ex1 {

	public static void main(String[] args) {
		
		Textarea_Ex1 myTextarea_Ex1 = new Textarea_Ex1();
		Employee_GUI myEmployee_GUI = new Employee_GUI(myTextarea_Ex1);
	}

}
