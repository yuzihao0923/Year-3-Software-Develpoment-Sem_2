package Ex1;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Ex1.Textarea_Ex1;

public class Employee_GUI implements ActionListener{

	private Textarea_Ex1 myTextarea1;
	Employee_store1 myEmployee_store;
	
	JTextField jTextField1 = new JTextField(10);
	JTextField jTextField2 = new JTextField(10);
	JTextField jTextField3 = new JTextField(10);
	JButton jButton1 = new JButton("Create Employee");
	JButton jButton2 = new JButton("Check Employee Count");
	
	public Employee_GUI(Textarea_Ex1 myTextarea) {

		myTextarea1 = myTextarea;
		myEmployee_store = new Employee_store1();
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		
		JLabel label1 = new JLabel("First Name");
		
		JLabel label2 = new JLabel("Last Name");
		
		JLabel label3 = new JLabel("Monthly Salary");
		
		jButton1.addActionListener(this);
		jButton2.addActionListener(this);
		
		
		cp.add(label1);
		cp.add(jTextField1);
		cp.add(label2);
		cp.add(jTextField2);
		cp.add(label3);
		cp.add(jTextField3);
		cp.add(jButton1);
		cp.add(jButton2);

		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==jButton1)
		{
			
			String theFirstName = jTextField1.getText();
			String theLastName = jTextField2.getText();
			double themonthly_salary = Double.parseDouble(jTextField3.getText());
							
			Employee1 myEmployee = new Employee1(theFirstName, theLastName, themonthly_salary);
			myEmployee_store.addEmployee(myEmployee);
			String msg = "Employee Object Created" + " " + myEmployee_store.getEmployee_StoreSize();
			myTextarea1.set_text(msg);			
		}
		
		if(e.getSource()==jButton2)
		{
			
			for(int i = 0 ; i < myEmployee_store.getEmployee_StoreSize(); i++)
			{
				String msg = "Number Of Employee's Created" + " " + myEmployee_store.getEmployee_StoreSize();
				myTextarea1.set_text(msg);			
				}
						
		}
	}
	
}
