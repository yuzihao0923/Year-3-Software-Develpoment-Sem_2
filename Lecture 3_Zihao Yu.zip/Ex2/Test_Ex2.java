package Ex2;

import Ex2.Employee_GUI;
import Ex2.Textarea_Ex2;

public class Test_Ex2 {

	public static void main(String[] args) {
			
			Textarea_Ex2 myTextarea_Ex2 = new Textarea_Ex2();
			Employee_GUI myEmployee_GUI = new Employee_GUI(myTextarea_Ex2);
		}

	}

