package Ex2;

import java.util.ArrayList;

public class Employee_store2 {

private ArrayList <Employee2> Employee2s;
	
	public Employee_store2()
	{
		Employee2s = new ArrayList<Employee2>();    
		
	}

	public void addEmployee(Employee2 e)
	{
		Employee2s.add(e);
	}
	
	public Employee2 getEmployee(int i)
	{
		return Employee2s.get(i);
	}
	
	public void removeEmployee(int i)
	{
		Employee2s.remove(i);
	}
	
	public int getEmployee_StoreSize()
	{
	
		return Employee2s.size();
	}
}
