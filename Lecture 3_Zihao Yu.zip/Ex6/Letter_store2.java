package Ex6;

import java.util.ArrayList;

public class Letter_store2 {

	private ArrayList <Letter2> Letter2s;
	
	public Letter_store2()
	{
		Letter2s = new ArrayList<Letter2>();    
		
	}

	public void addLetter(Letter2 e)
	{
		Letter2s.add(e);
	}
	
	public Letter2 getLetter(int i)
	{
		return Letter2s.get(i);
	}
	
	public void removeLetter(int i)
	{
		Letter2s.remove(i);
	}
	
	public int getLetter_StoreSize()
	{
	
		return Letter2s.size();
	}
}
