package Ex6;

public class Letter2 {

	private String recipient_name;
	private String sender_name;
	private String line = "";
	
	
	public Letter2(String recipient_name, String sender_name,String line) {
		super();
		this.recipient_name = recipient_name;
		this.sender_name = sender_name;
		this.line = line;
	}

	public String getRecipient_name() {
		return recipient_name;
	}

	public void setRecipient_name(String recipient_name) {
		this.recipient_name = recipient_name;
	}

	public String getSender_name() {
		return sender_name;
	}

	public void setSender_name(String sender_name) {
		this.sender_name = sender_name;
	}
	
	public String getLine() {
		return line;
	}

	public String setLine(String newline) {
		this.line = this.line + "\n" + newline;
		return this.line;
	}
	
	public String printLetter()
	{
		
		String msg = "";
		
		msg = "Dear " + recipient_name + "\n" + "\n"
				+ line + "\n"
				+ "sincerely," + "\n"
				+ sender_name;
		return msg;
}
}
