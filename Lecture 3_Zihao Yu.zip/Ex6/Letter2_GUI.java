package Ex6;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Letter2_GUI implements ActionListener{

	private Letter2 myLetter2;
	private Textarea_Ex6 myTextarea6;
	
	JButton jButton1 = new JButton("Create Letter");
	JButton jButton2 = new JButton("Print All Letter's");
	JCheckBox checkNewLetter = new JCheckBox("New Letter");

	
	JTextField jTextField1 = new JTextField(20);
	JTextField jTextField2 = new JTextField(20);
	JTextField jTextField3 = new JTextField(20);

	Letter_store2 myLetter_store2;
	
    public Letter2_GUI(Textarea_Ex6 myTextarea) {
    	
    	myLetter2 = null;
    	
    	myTextarea6 = myTextarea;
    	myLetter_store2 = new Letter_store2();
    	
    	JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		myLetter_store2 = new Letter_store2();
		
		JLabel label1 = new JLabel("To");
		JLabel label2 = new JLabel("From");
		JLabel label3 = new JLabel("Line");
		
		
		jButton1.addActionListener(this);
		jButton2.addActionListener(this);
		
		
		
		cp.add(label1);
		cp.add(jTextField1);
		cp.add(label2);
		cp.add(jTextField2);
		cp.add(label3);
		cp.add(jTextField3);
		cp.add(jButton1);
		cp.add(checkNewLetter);
		cp.add(jButton2);
		
		frame.setSize(500, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

    }
    public void actionPerformed(ActionEvent e) {
        	
	    	String therecipient_name = jTextField1.getText();
			String thesender_name = jTextField2.getText();
			String theline = jTextField3.getText();
		
    	
			if(checkNewLetter.isSelected()) {
        		if(e.getSource() == jButton1) {
        			
        			myLetter2 = new Letter2(therecipient_name, thesender_name,theline);
            		myLetter_store2.addLetter(myLetter2);
            		String msg = "Letter Created...";
            		myTextarea6.set_text(msg);
        		}
        	}else {
			
			if(e.getSource() == jButton1) 
        	{
        		if(myLetter2 == null) {
        		
        	    myLetter2 = new Letter2(therecipient_name, thesender_name,theline);
        		myLetter_store2.addLetter(myLetter2);
        		String msg = "Letter Created...";
        		myTextarea6.set_text(msg);
        		}
        		
        		else{
        			
        		theline = myLetter2.setLine(jTextField3.getText());
       			String msg1 = "Letter upDated...";
       			myTextarea6.set_text(msg1);
        		
        		}
        	}
        	
        	
        	}
        	
        	
        	if(e.getSource() == jButton2)
    		{
    			for(int i = 0 ; i < myLetter_store2.getLetter_StoreSize(); i++)
    			{
    				myTextarea6.set_text(myLetter_store2.getLetter(i).printLetter());
    			}
    		}
        	

}
}


