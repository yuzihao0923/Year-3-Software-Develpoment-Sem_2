package Ex6;

public class Test_Ex6 {

	public static void main(String[] args) {
		
		Textarea_Ex6 myTextarea_Ex6 = new Textarea_Ex6();
		Letter2_GUI myLetter_GUI = new Letter2_GUI(myTextarea_Ex6);
	}

}
