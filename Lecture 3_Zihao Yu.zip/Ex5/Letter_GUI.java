package Ex5;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Letter_GUI implements ActionListener{

	Letter_store myLetter_store;
	
	private Textarea_Ex5 myTextarea5;
	JButton jButton1 = new JButton("Create Letter");
	JButton jButton2 = new JButton("Print All Letter's");

	
	JTextField jTextField1 = new JTextField(20);
	JTextField jTextField2 = new JTextField(20);
	JTextField jTextField3 = new JTextField(20);

    public Letter_GUI(Textarea_Ex5 myTextarea) {
    	
    	myTextarea5 = myTextarea;
    	myLetter_store = new Letter_store();
    	
    	JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		JLabel label1 = new JLabel("To");
		JLabel label2 = new JLabel("From");
		JLabel label3 = new JLabel("Line");
		
		
		jButton1.addActionListener(this);
		jButton2.addActionListener(this);
		
		
		
		cp.add(label1);
		cp.add(jTextField1);
		cp.add(label2);
		cp.add(jTextField2);
		cp.add(label3);
		cp.add(jTextField3);
		cp.add(jButton1);
		cp.add(jButton2);
		
		frame.setSize(500, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

    }
    public void actionPerformed(ActionEvent e) {
    	if(e.getSource() == jButton1) {
    		
    		String therecipient_name = jTextField1.getText();
    		String thesender_name = jTextField2.getText();
    		String thetxt = jTextField3.getText();
    		
    		Letter myLetter = new Letter(therecipient_name,thesender_name,thetxt);
    		myLetter_store.addLetter(myLetter);
    		String msg = "Letter Created...";
    		myTextarea5.set_text(msg);
    	}
    	if(e.getSource() == jButton2) {
    		
    		for(int i = 0 ; i < myLetter_store.getLetter_StoreSize(); i++)
			{

    			myTextarea5.set_text(myLetter_store.getLetter(i).printLetter());
				
				}
    	}
    }
    
}
