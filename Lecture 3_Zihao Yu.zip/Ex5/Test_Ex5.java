package Ex5;

public class Test_Ex5 {

	public static void main(String[] args) {
		
		Textarea_Ex5 myTextarea_Ex5 = new Textarea_Ex5();
		Letter_GUI myLetter_GUI = new Letter_GUI(myTextarea_Ex5);
	}

}
