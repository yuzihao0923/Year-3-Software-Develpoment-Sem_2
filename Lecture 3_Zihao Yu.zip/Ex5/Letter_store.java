package Ex5;

import java.util.ArrayList;

public class Letter_store {

	private ArrayList <Letter> Letters;
	
	public Letter_store()
	{
		Letters = new ArrayList<Letter>();    
		
	}

	public void addLetter(Letter e)
	{
		Letters.add(e);
	}
	
	public Letter getLetter(int i)
	{
		return Letters.get(i);
	}
	
	public void removeLetter(int i)
	{
		Letters.remove(i);
	}
	
	public int getLetter_StoreSize()
	{
	
		return Letters.size();
	}
}
