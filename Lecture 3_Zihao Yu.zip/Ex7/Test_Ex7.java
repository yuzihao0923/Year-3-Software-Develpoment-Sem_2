package Ex7;

public class Test_Ex7 {

	public static void main(String[] args) {
		
		Textarea_Ex7 myTextarea_Ex7 = new Textarea_Ex7();
		Address_GUI myAddress_GUI = new Address_GUI(myTextarea_Ex7);
	}

}
