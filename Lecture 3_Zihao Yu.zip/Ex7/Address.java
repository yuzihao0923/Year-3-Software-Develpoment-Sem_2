package Ex7;

public class Address {
	private String house_number;
	private String optional_apartment_number;
	private String street;
	private String town;
	private String country;
	private String postal_number;
	
	public Address(String house_number, String optional_apartment_number, String street, String town,
			String country, String postal_number) {
		super();
		this.house_number = house_number;
		this.optional_apartment_number = optional_apartment_number;
		this.street = street;
		this.town = town;
		this.country = country;
		this.postal_number = postal_number;
	}

	public String getHouse_number() {
		return house_number;
	}

	public void setHouse_number(String house_number) {
		this.house_number = house_number;
	}

	public String getOptional_apartment_number() {
		return optional_apartment_number;
	}

	public void setOptional_apartment_number(String optional_apartment_number) {
		this.optional_apartment_number = optional_apartment_number;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostal_number() {
		return postal_number;
	}

	public void setPostal_number(String postal_number) {
		this.postal_number = postal_number;
	}
	 
	public String printaddress() 
	{
		String msg = house_number + "\n"
				+ optional_apartment_number + "\n"
				+ street + "\n"
				+ town + "\n"
				+ country + "\n"
				+ postal_number + "\n";
		return msg;
	}
	
	public boolean searchString(String strToSearch) {
		return this.house_number.contains(strToSearch) || this.optional_apartment_number.contains(strToSearch)
				|| this.street.contains(strToSearch) || this.town.contains(strToSearch)
				|| this.country.contains(strToSearch) || this.postal_number.contains(strToSearch);
	}
}

