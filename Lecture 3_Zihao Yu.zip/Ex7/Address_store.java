package Ex7;

import java.util.ArrayList;

public class Address_store {

private ArrayList <Address> Addresses;
	
	public Address_store()
	{
		Addresses = new ArrayList<Address>();    
		
	}

	public void addAddress(Address e)
	{
		Addresses.add(e);
	}
	
	public Address getAddress(int i)
	{
		return Addresses.get(i);
	}
	
	public void removeAddress(int i)
	{
		Addresses.remove(i);
	}
	
	public int getAddress_StoreSize()
	{
	
		return Addresses.size();
	}
	
	public ArrayList<Address> searchAddress(String strToSearch) {
		ArrayList<Address> tmpAddresses = new ArrayList<Address>();
		for (int i = 0; i  < this.getAddress_StoreSize(); i++) {
			if (this.getAddress(i).searchString(strToSearch)) {
				tmpAddresses.add(this.getAddress(i));
			}
		}
		return tmpAddresses;
	}

}
