package Ex7;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Address_GUI implements ActionListener {

	Address_store myAddress_store;

	private Address myAddress;
	private Textarea_Ex7 myTextarea7;

	JButton jButton1 = new JButton("Create Address");
	JButton jButton2 = new JButton("Print Addresses");
	JButton jButton3 = new JButton("Search");

	JTextField jTextField1 = new JTextField(20);
	JTextField jTextField2 = new JTextField(20);
	JTextField jTextField3 = new JTextField(20);

	JTextField jTextField4 = new JTextField(20);
	JTextField jTextField5 = new JTextField(20);
	JTextField jTextField6 = new JTextField(20);

	JTextField jTextField7 = new JTextField(20);

	public Address_GUI(Textarea_Ex7 myTextarea) {

		myAddress_store = new Address_store();

		myTextarea7 = myTextarea;

		JFrame frame = new JFrame();
		frame.setTitle("JFrame Example");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		Box b0 = new Box(BoxLayout.Y_AXIS);
		Box b1 = new Box(BoxLayout.Y_AXIS);

		JLabel label1 = new JLabel("House Number");
		JLabel label2 = new JLabel("Appt Number");
		JLabel label3 = new JLabel("Street");

		b0.add(label1);
		b0.add(label2);
		b0.add(label3);

		b1.add(jTextField1);
		b1.add(jTextField2);
		b1.add(jTextField3);

		Box b2 = new Box(BoxLayout.Y_AXIS);
		Box b3 = new Box(BoxLayout.Y_AXIS);

		JLabel label4 = new JLabel("Town");
		JLabel label5 = new JLabel("Country");
		JLabel label6 = new JLabel("Postal Code");

		b2.add(label4);
		b2.add(label5);
		b2.add(label6);

		b3.add(jTextField4);
		b3.add(jTextField5);
		b3.add(jTextField6);

		jButton1.addActionListener(this);
		jButton2.addActionListener(this);
		jButton3.addActionListener(this);

		JTextArea jta7 = new JTextArea("", 10, 20);

		cp.add(b0);
		cp.add(b1);
		cp.add(b2);
		cp.add(b3);

		cp.add(jButton1);
		cp.add(jButton2);
		cp.add(jButton3);
		cp.add(jTextField7);

		frame.setSize(400, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == jButton1) {

			String thehouse_number = jTextField1.getText();
			String theoptional_apartment_number = jTextField2.getText();
			String thestreet = jTextField3.getText();
			String thetown = jTextField4.getText();
			String thecountry = jTextField5.getText();
			String thepostal_number = jTextField6.getText();

			Address myAddress = new Address(thehouse_number, theoptional_apartment_number, thestreet, thetown,
					thecountry, thepostal_number);
			myAddress_store.addAddress(myAddress);

			String msg;
			msg = "Address Object Created...";
			myTextarea7.set_text(msg);
		}
		if (e.getSource() == jButton2) {

			for (int i = 0; i < myAddress_store.getAddress_StoreSize(); i++) {

				myTextarea7.set_text(myAddress_store.getAddress(i).printaddress());

			}
		}
		if (e.getSource() == jButton3) {
			String searchStr = jTextField7.getText();
			ArrayList<Address> searchedAddresses = myAddress_store.searchAddress(searchStr);
			String msg = "";
			for (int i = 0; i < searchedAddresses.size(); i++) {

				msg += (searchedAddresses.get(i).printaddress());
				msg += "\r\n";

			}
			myTextarea7.set_text(msg);

		}

	}
}
