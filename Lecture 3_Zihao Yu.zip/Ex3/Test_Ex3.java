package Ex3;

import Ex3.SavingsAccount_GUI;
import Ex3.Textarea_Ex3;

public class Test_Ex3 {

	public static void main(String[] args) {
		Textarea_Ex3 myTextarea_Ex3 = new Textarea_Ex3();
		SavingsAccount_GUI mySavingsAccount_GUI = new SavingsAccount_GUI(myTextarea_Ex3);

	}

}
