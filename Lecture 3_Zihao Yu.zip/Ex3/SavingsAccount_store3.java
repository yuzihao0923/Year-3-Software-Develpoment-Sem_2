package Ex3;

import java.util.ArrayList;

import Ex2.Employee2;

public class SavingsAccount_store3 {

private ArrayList <SavingsAccount> SavingsAccount;
	
	public SavingsAccount_store3()
	{
		SavingsAccount = new ArrayList<SavingsAccount>();    
		
	}

	public void addSavingsAccount(SavingsAccount e)
	{
		SavingsAccount.add(e);
	}
	
	public SavingsAccount getSavingsAccount(int i)
	{
		return SavingsAccount.get(i);
	}
	
	public void removeSavingsAccount(int i)
	{
		SavingsAccount.remove(i);
	}
	
	public int getSavingsAccount_StoreSize()
	{
	
		return SavingsAccount.size();
	}
}
