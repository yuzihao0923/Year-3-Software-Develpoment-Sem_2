package Ex3;

public class SavingsAccount {

	private String First_name;
	private String Last_name;
	private double savingsBalance ;
	private double InterstedMade;
	private double NewBalance;
	
	public static double annualInterestRate;
	

	
	public SavingsAccount(String first_name, String last_name, double savingsBalance) {
		super();
		this.First_name = first_name;
		this.Last_name = last_name;
		this.savingsBalance = savingsBalance;

	}


	public String getFirst_name() {
		return First_name;
	}


	public void setFirst_name(String first_name) {
		First_name = first_name;
	}


	public String getLast_name() {
		return Last_name;
	}


	public void setLast_name(String last_name) {
		Last_name = last_name;
	}

	public double getInterstedMade() {
		return InterstedMade;
	}


	public void setInterstedMade(double interstedMade) {
		InterstedMade = interstedMade;
	}


	public double getNewBalance() {
		return NewBalance;
	}


	public void setNewBalance(double newBalance) {
		NewBalance = newBalance;
	}


	public double getSavingsBalance() {
		return savingsBalance;
	}

	public void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}

	public double getAnnualInterestRate(double rate) {
		return annualInterestRate = rate;
	}
	

//	public static void setAnnualInterestRate(double annualInterestRate) {
//		SavingsAccount.annualInterestRate = annualInterestRate;
//	}
		
	public static double getAnnualInterestRate() {
		return annualInterestRate;
	}


	public static void setAnnualInterestRate(double annualInterestRate) {
		SavingsAccount.annualInterestRate = annualInterestRate;
	}


	public String calculateMonthlyInterest() {

		
		InterstedMade = Math.round(savingsBalance * annualInterestRate);
		NewBalance = savingsBalance + InterstedMade;
		
		String msg = First_name + " " + Last_name + "\n" 
					+ "Interest Rate -- " + annualInterestRate + "\n" 
					+ "Interested made -- " + InterstedMade + "\n"
					+ "New Balance -- " + NewBalance;
		
		return msg;
		
	}
}
