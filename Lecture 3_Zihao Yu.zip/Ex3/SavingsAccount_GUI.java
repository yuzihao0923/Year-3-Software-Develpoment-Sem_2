package Ex3;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class SavingsAccount_GUI implements ActionListener{

	private Textarea_Ex3 myTextarea3;
	SavingsAccount_store3 mySavingsAccount_store;
	
	
	JTextField jTextField1 = new JTextField(10);
	JTextField jTextField2 = new JTextField(10);
	JTextField jTextField3 = new JTextField(10);
	JTextField jTextField4 = new JTextField(10);

	JButton jButton1 = new JButton("Create Account");
	JButton jButton2 = new JButton("All Next Months Balance's");
	
	public SavingsAccount_GUI(Textarea_Ex3 myTextarea_Ex3) {
		
		myTextarea3 = myTextarea_Ex3;
		mySavingsAccount_store = new SavingsAccount_store3();
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		
		
		JLabel label1 = new JLabel("First Name");
		
		JLabel label2 = new JLabel("Last Name");
		JLabel label3 = new JLabel("Statring Balance");
		JLabel label4 = new JLabel("Interest Rate");
		
		
		
		
		jButton1.addActionListener(this);
		jButton2.addActionListener(this);
		
		
		cp.add(label1);
		cp.add(jTextField1);
		cp.add(label2);
		cp.add(jTextField2);
		cp.add(label3);
		cp.add(jTextField3);
		cp.add(jButton1);
		cp.add(jButton2);
		cp.add(label4);
		cp.add(jTextField4);
		
		
		
		
		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == jButton1) {
			
			String theFirstName = jTextField1.getText();
			String theLastName = jTextField2.getText();
			double thesavingsBalance = Double.valueOf(jTextField3.getText());
			double theInterstedMade = Double.valueOf(jTextField3.getText())*Double.valueOf(jTextField4.getText());
			double theNewBalance = theInterstedMade + thesavingsBalance;
			double theannualInterestRate = Double.valueOf(jTextField4.getText());
							
			SavingsAccount mySavingsAccount = new SavingsAccount(theFirstName, theLastName, thesavingsBalance);
			mySavingsAccount.setAnnualInterestRate(theannualInterestRate);
			mySavingsAccount_store.addSavingsAccount(mySavingsAccount);
			String msg = "Saving Account Objects Created" + " " + mySavingsAccount_store.getSavingsAccount_StoreSize();
			myTextarea3.set_text(msg);	
		}
		
		if(e.getSource() == jButton2) {

			for(int i = 0 ; i < mySavingsAccount_store.getSavingsAccount_StoreSize(); i++)
			{

				myTextarea3.set_text(mySavingsAccount_store.getSavingsAccount(i).calculateMonthlyInterest());
				
				}
		}
	}
}
