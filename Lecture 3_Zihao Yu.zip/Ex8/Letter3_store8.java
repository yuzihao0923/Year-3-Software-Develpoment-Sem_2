package Ex8;

import java.util.ArrayList;


public class Letter3_store8 {

private ArrayList <Letter3> Letter3s;
	
	public Letter3_store8()
	{
		Letter3s = new ArrayList<Letter3>();    
		
	}

	public void addLetter(Letter3 e)
	{
		Letter3s.add(e);
	}
	
	public Letter3 getLetter(int i)
	{
		return Letter3s.get(i);
	}
	
	public void removeLetter(int i)
	{
		Letter3s.remove(i);
	}
	
	public int getLetter_StoreSize()
	{
	
		return Letter3s.size();
	}
	
	
}
