package Ex8;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Ex6.Letter2;
import Ex6.Textarea_Ex6;

public class Letter3_GUI implements ActionListener{

	private Letter3 myLetter3;
	private Textarea_Ex8 myTextarea8;
	
	JComboBox<String> distiation;
	
	JButton jButton1 = new JButton("Create Letter");
	JButton jButton2 = new JButton("Print All Letter's");
	JCheckBox checkNewLetter = new JCheckBox("New Letter");

	
	JTextField jTextField1 = new JTextField(20);
	JTextField jTextField2 = new JTextField(20);
	JTextField jTextField3 = new JTextField(20);
	
	Letter3_store8 myLetter3_store8;
	
	public Letter3_GUI(Textarea_Ex8 myTextarea) {
		
		myLetter3 = null;
		
		myTextarea8 = myTextarea;
		myLetter3_store8 = new Letter3_store8();
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		JLabel label1 = new JLabel("To");
		JLabel label2 = new JLabel("From");
		JLabel label3 = new JLabel("Line");
		
		
		jButton1.addActionListener(this);
		jButton2.addActionListener(this);
		
		distiation = new JComboBox<String>();
		distiation.addItem("-Select-");

		distiation.addActionListener(this);
		
		cp.add(label1);
		cp.add(jTextField1);
		cp.add(label2);
		cp.add(jTextField2);
		cp.add(label3);
		cp.add(jTextField3);
		cp.add(jButton1);
		cp.add(checkNewLetter);
		cp.add(jButton2);
		cp.add(distiation);
		
		frame.setSize(500, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
	
	public void updateDropDown( ) {
		distiation.removeAllItems();
		distiation.addItem("-Select-");
		for(int i = 0 ; i < myLetter3_store8.getLetter_StoreSize(); i++)
			{
			Letter3 letter = myLetter3_store8.getLetter(i);
			distiation.addItem("To " + letter.getRecipient_name() + " From " + letter.getSender_name());
			}
	}
		
	public void actionPerformed(ActionEvent e) {

		String therecipient_name = jTextField1.getText();
		String thesender_name = jTextField2.getText();
		String theline = jTextField3.getText();

		if (checkNewLetter.isSelected()) {
			if (e.getSource() == jButton1) {

				myLetter3 = new Letter3(therecipient_name, thesender_name, theline);
				myLetter3_store8.addLetter(myLetter3);
				updateDropDown();
				String msg = "Letter Created...";
				myTextarea8.set_text(msg);
			}
		} else {

			if (e.getSource() == jButton1) {
				if (myLetter3 == null) {

					myLetter3 = new Letter3(therecipient_name, thesender_name, theline);
					myLetter3_store8.addLetter(myLetter3);
					updateDropDown();
					String msg = "Letter Created...";
					myTextarea8.set_text(msg);
				}

				else {

					theline = myLetter3.setLine(jTextField3.getText());
					String msg1 = "Letter upDated...";
					myTextarea8.set_text(msg1);

				}
			}

		}

		if (e.getSource() == jButton2) {
			for (int i = 0; i < myLetter3_store8.getLetter_StoreSize(); i++) {
				myTextarea8.set_text(myLetter3_store8.getLetter(i).printLetter());
			}
		}
		
		if((e.getSource() == distiation) && (distiation.getSelectedIndex() != -1) && (distiation.getSelectedIndex() != 0)) {
			Letter3 letter = myLetter3_store8.getLetter(distiation.getSelectedIndex() - 1);
			myTextarea8.set_text(letter.printLetter());
		}
		
		
	}

}
