package Ex8;

import Ex8.Letter3_GUI;
import Ex8.Textarea_Ex8;

public class Test_Ex8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Textarea_Ex8 myTextarea_Ex8 = new Textarea_Ex8();
		Letter3_GUI myLetter_GUI = new Letter3_GUI(myTextarea_Ex8);
	}

}
