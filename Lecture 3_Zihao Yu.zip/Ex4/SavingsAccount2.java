package Ex4;

public class SavingsAccount2 {

	private String First_name;
	private String Last_name;
	private double savingsBalance ;
	private double InterstedMade;
	private double NewBalance;
	private double annualInterestRate;
	

	
	public SavingsAccount2(String first_name, String last_name, double savingsBalance, double interstedMade,
			double newBalance) {
		super();
		this.First_name = first_name;
		this.Last_name = last_name;
		this.savingsBalance = savingsBalance;
		this.InterstedMade = interstedMade;
		this.NewBalance = newBalance;
	}


	public String getFirst_name() {
		return First_name;
	}


	public void setFirst_name(String first_name) {
		First_name = first_name;
	}


	public String getLast_name() {
		return Last_name;
	}


	public void setLast_name(String last_name) {
		Last_name = last_name;
	}

	public double getInterstedMade() {
		return InterstedMade;
	}


	public void setInterstedMade(double interstedMade) {
		InterstedMade = interstedMade;
	}


	public double getNewBalance() {
		return NewBalance;
	}


	public void setNewBalance(double newBalance) {
		NewBalance = newBalance;
	}


	public double getSavingsBalance() {
		return savingsBalance;
	}

	public void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}

	public double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}
		
	public String calculateMonthlyInterest() {

		
		InterstedMade = Math.round(savingsBalance * annualInterestRate);
		NewBalance = savingsBalance + InterstedMade;
		
		String msg = First_name + " " + Last_name + "\n" 
					+ "Interest Rate -- " + annualInterestRate + "\n" 
					+ "Interested made -- " + InterstedMade + "\n"
					+ "New Balance -- " + NewBalance;
		
		return msg;
		
	}
}