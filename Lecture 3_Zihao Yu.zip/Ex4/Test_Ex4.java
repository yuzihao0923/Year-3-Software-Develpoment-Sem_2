package Ex4;

import Ex4.SavingsAccount2_GUI;
import Ex4.Textarea_Ex4;

public class Test_Ex4 {

	public static void main(String[] args) {
		
		Textarea_Ex4 myTextarea_Ex4 = new Textarea_Ex4();
		SavingsAccount2_GUI mySavingsAccount2_GUI = new SavingsAccount2_GUI(myTextarea_Ex4);
	}

}
