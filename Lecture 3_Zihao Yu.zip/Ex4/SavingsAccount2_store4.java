package Ex4;

import java.util.ArrayList;

public class SavingsAccount2_store4 {

private ArrayList <SavingsAccount2> SavingsAccount2;
	
	public  SavingsAccount2_store4()
	{
		SavingsAccount2 = new ArrayList<SavingsAccount2>();    
		
	}

	public void addSavingsAccount2(SavingsAccount2 e)
	{
		SavingsAccount2.add(e);
	}
	
	public SavingsAccount2 getSavingsAccount2(int i)
	{
		return SavingsAccount2.get(i);
	}
	
	public void removeSavingsAccount(int i)
	{
		SavingsAccount2.remove(i);
	}
	
	public int getSavingsAccount_StoreSize()
	{
	
		return SavingsAccount2.size();
	}
}
