package Ex4;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Ex3.SavingsAccount;
import Ex4.SavingsAccount2;
import Ex4.SavingsAccount2_store4;
import Ex4.Textarea_Ex4;

public class SavingsAccount2_GUI implements ActionListener{

	private Textarea_Ex4 myTextarea4;
	SavingsAccount2_store4 mySavingsAccount_store4;
	
	
	JTextField jTextField1 = new JTextField(10);
	JTextField jTextField2 = new JTextField(10);
	JTextField jTextField3 = new JTextField(10);
	JTextField jTextField4 = new JTextField(10);

	JButton jButton1 = new JButton("Create Account");
	JButton jButton2 = new JButton("All Next Months Balance's");
	
	public SavingsAccount2_GUI(Textarea_Ex4 myTextarea_Ex4) {
		
		myTextarea4 = myTextarea_Ex4;
		mySavingsAccount_store4 = new SavingsAccount2_store4();
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		
		
		JLabel label1 = new JLabel("First Name");
		
		JLabel label2 = new JLabel("Last Name");
		JLabel label3 = new JLabel("Statring Balance");
		JLabel label4 = new JLabel("Interest Rate");
		
		
		
		
		jButton1.addActionListener(this);
		jButton2.addActionListener(this);
		
		
		cp.add(label1);
		cp.add(jTextField1);
		cp.add(label2);
		cp.add(jTextField2);
		cp.add(label3);
		cp.add(jTextField3);
		cp.add(jButton1);
		cp.add(jButton2);
		cp.add(label4);
		cp.add(jTextField4);
		
		
		
		
		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == jButton1) {
			
			String theFirstName = jTextField1.getText();
			String theLastName = jTextField2.getText();
			double thesavingsBalance = Double.valueOf(jTextField3.getText());
			double theInterstedMade = Double.valueOf(jTextField3.getText())*Double.valueOf(jTextField4.getText());
			double theNewBalance = theInterstedMade + thesavingsBalance;
			double theannualInterestRate = Double.valueOf(jTextField4.getText());
							
			SavingsAccount2 mySavingAccount = new SavingsAccount2(theFirstName, theLastName, thesavingsBalance, theannualInterestRate, theannualInterestRate);
			mySavingsAccount_store4.addSavingsAccount2(mySavingAccount);
			String msg = "Saving Account Objects Created" + " " + mySavingsAccount_store4.getSavingsAccount_StoreSize();
			myTextarea4.set_text(msg);	
		}
		
		if(e.getSource() == jButton2) {

			for(int i = 0 ; i < mySavingsAccount_store4.getSavingsAccount_StoreSize(); i++)
			{

				myTextarea4.set_text(mySavingsAccount_store4.getSavingsAccount2(i).calculateMonthlyInterest());
				
				}
		}
	}
}
