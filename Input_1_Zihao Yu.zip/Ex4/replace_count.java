package Ex4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class replace_count {

public replace_count() throws FileNotFoundException {
		
		Scanner console = new Scanner(System.in); 
		
		// SETUP to read the file
		System.out.print("Input file: ");
		String inputFileName = console.next(); 
		File inputFile = new File(inputFileName); 	
		Scanner in = new Scanner(inputFile); 
		Scanner in2 = new Scanner(inputFile); 

		
		// Creates an new output file 
		System.out.print("Output file: "); 
		String outputFileName = console.next();
		PrintWriter out = new PrintWriter(outputFileName);

		
		
		 while (in.hasNext())
		   {
		     String value = in.next();
		     int letterCount = 0;
//		     value.split(value);
//		     value = in.next();
			     for(int i=0;i<value.length();i++)
			     {
			     	char ch = value.charAt(i);
			     	letterCount++;
			     }	
			     out.print(letterCount + " ");
		     
		    }
		
		
		 
		

		
		
		in.close();
		out.close();

	}

}


