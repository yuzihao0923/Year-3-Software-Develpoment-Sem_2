package Ex6;

import java.io.FileNotFoundException;

public class Test {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		replace_count myreplace_count = new replace_count();
	}

}
