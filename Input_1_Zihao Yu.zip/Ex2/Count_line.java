package Ex2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Count_line {

	public Count_line() throws FileNotFoundException{
		
		// Prompt for the input and output file names
		Scanner console = new Scanner(System.in); 
		
		// SETUP to read the file
		System.out.print("Input file: ");
		String inputFileName = console.next(); 
		File inputFile = new File(inputFileName); 	
		Scanner in = new Scanner(inputFile); 
		Scanner in2 = new Scanner(inputFile); 
		
		// Creates an new output file 
		System.out.print("Output file: "); 
		String outputFileName = console.next();
		PrintWriter out = new PrintWriter(outputFileName);
		

		// Read the input and write the output
			int count = 0;

			while (in2.hasNextLine()) 
			{ 
				count++;
				String value = in2.nextLine(); 

				out.println(value);
			}
			
			while (in.hasNextLine()) 
			{ 
				count++;
				String value = in.nextLine(); 

				out.println("/*" + count + "*/  " + value);
			}
			
			


			
			in.close();
			out.close(); 
			console.close();
	}
}
