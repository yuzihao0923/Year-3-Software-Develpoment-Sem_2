package Ex2;

import java.io.FileNotFoundException;

public class Test {

	public static void main(String[] args) throws FileNotFoundException{
		// TODO Auto-generated method stub
		Count_line myCount_line = new Count_line();
	}

}
