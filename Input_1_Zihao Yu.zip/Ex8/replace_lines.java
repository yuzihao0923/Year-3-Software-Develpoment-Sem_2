package Ex8;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class replace_lines {

	public replace_lines() throws FileNotFoundException {
	Scanner console = new Scanner(System.in); 
	
	// SETUP to read the file
	System.out.print("Input file: ");
	String inputFileName = console.next(); 
	File inputFile = new File(inputFileName); 	
	Scanner in = new Scanner(inputFile); 

	
	// Creates an new output file 
	System.out.print("Output file: "); 
	String outputFileName = console.next();
	PrintWriter out = new PrintWriter(outputFileName);


	while (in.hasNextLine()) 
	{ 	
		String value = in.next(); 
		if(in.hasNext() == true) {	
			if(value.equals("Mary") )
			{
				out.print("Tom");
			}
			else
			{
				out.print(value);
			if(value.equals("lamb")) 
			{
				out.print("\n");
			}
			
			
		}
		}else 
			{
				out.print(value);
			}
		out.print(" ");
	
			
	}
	
	out.println("");

	
	in.close();
	out.close();

}
}
