package Ex8;

import java.io.FileNotFoundException;

import Ex7.replace_wordscount;

public class Test {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		replace_lines myreplace_lines = new replace_lines();
	}

}
