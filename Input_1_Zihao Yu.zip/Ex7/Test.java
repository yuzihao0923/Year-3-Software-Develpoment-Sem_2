package Ex7;

import java.io.FileNotFoundException;

import Ex6.replace_count;

public class Test {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		replace_wordscount myreplace_wordscount = new replace_wordscount();
	}

}
