package Ex7;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class replace_wordscount {

public replace_wordscount() throws FileNotFoundException {
		
		Scanner console = new Scanner(System.in); 
		
		// SETUP to read the file
		System.out.print("Input file: ");
		String inputFileName = console.next(); 
		File inputFile = new File(inputFileName); 	
		Scanner in = new Scanner(inputFile); 

		
		// Creates an new output file 
		System.out.print("Output file: "); 
		String outputFileName = console.next();
		PrintWriter out = new PrintWriter(outputFileName);

		int count = 0;

		while (in.hasNext()) 
		{ 	
		//	count++;
			String value = in.next(); 

				
				if(value.equals("Mary") )
				{
					out.print("Tom");
					count++;
				}
				else
				{
					out.print(value);

				
			}
		
			out.print(" ");
		
		
		}
		
		out.println("");
		out.println("The number of words is " + count);
		
		in.close();
		out.close();

}
}