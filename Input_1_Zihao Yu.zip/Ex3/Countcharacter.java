package Ex3;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Countcharacter {

	public Countcharacter() throws FileNotFoundException {
		
		Scanner console = new Scanner(System.in); 
		
		// SETUP to read the file
		System.out.print("Input file: ");
		String inputFileName = console.next(); 
		File inputFile = new File(inputFileName); 	
		Scanner in = new Scanner(inputFile); 
		Scanner in2 = new Scanner(inputFile); 

		
		// Creates an new output file 
		System.out.print("Output file: "); 
		String outputFileName = console.next();
		PrintWriter out = new PrintWriter(outputFileName);
	     
		
		int count = 0;
		int letterCount = 0;
		int countline = 0;
	   	 int countwords = 0;
		
		while (in2.hasNextLine()) 
		{ 
			countline++;
			String value1 = in2.nextLine(); 

	//		out.println(value1);
		}

	    while (in.hasNext())
		   {
	    	countwords++;
		     String value2 = in.next();

			     for(int i=0;i<value2.length();i++)
			     {
			     	char ch = value2.charAt(i);
			     	letterCount++;
			     }	     
		   }
	     	     
//	     while (in.hasNext()) 
//			{ 
//				countline++;
//				String value3 = in.next(); 
//					
//			}
//		
//
//	     
//	     while (in.hasNextLine()) 
//			{ 
//				countwords++;
//				String value4 = in.nextLine(); 
//			
//
//			}
			
	        out.println("The number of letters in text is  " + letterCount);
			out.println("The number of lines is " + countline);
		    out.println("The number of words is " + countwords);

			
	     in.close();
		 out.close();

	}
}