package Ex3;

import java.io.FileNotFoundException;

public class Test {

	public static void main(String[] args) throws FileNotFoundException{
		// TODO Auto-generated method stub
		Countcharacter myCount = new Countcharacter();

	}

}
