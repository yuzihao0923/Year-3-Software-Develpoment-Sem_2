package Ex5;

import java.io.FileNotFoundException;

import Ex4.replace_count;

public class Test {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		countwords_characters mycountwords_characters = new countwords_characters();
	}

}
