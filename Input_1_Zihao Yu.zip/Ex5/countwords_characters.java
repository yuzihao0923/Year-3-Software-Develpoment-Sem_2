package Ex5;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class countwords_characters {

public countwords_characters() throws FileNotFoundException {
		
		Scanner console = new Scanner(System.in); 
		
		// SETUP to read the file
		System.out.print("Input file: ");
		String inputFileName = console.next(); 
		File inputFile = new File(inputFileName); 	
		Scanner in = new Scanner(inputFile); 
		Scanner in2 = new Scanner(inputFile); 

		
		// Creates an new output file 
		System.out.print("Output file: "); 
		String outputFileName = console.next();
		PrintWriter out = new PrintWriter(outputFileName);

		 int count = 0;
		
		 while (in.hasNext())
		   {
		     
		     int letterCount = 0;
		    
		     String value = in.next();
		     count++;

			     for(int i=0;i<value.length();i++)
			     {
			     	char ch = value.charAt(i);
			     	letterCount++;
			     }	
			     out.print(letterCount + " ");
			     
		    }
		 out.println("");
		 out.println("Number of words " + count);
		
		
		in.close();
		out.close();

	}

}

