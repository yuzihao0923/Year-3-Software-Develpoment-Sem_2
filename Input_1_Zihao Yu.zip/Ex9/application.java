package Ex9;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class application implements ActionListener{

	JButton jButton = new JButton("CLICK");
	JTextField jTextField1 = new JTextField(20);
	JTextField jTextField2 = new JTextField(20);

	
	public application() {
		JFrame frame = new JFrame();
		frame.setTitle("JFrame Example");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		
		JLabel label1 = new JLabel("File Name: ");
		JLabel label2 = new JLabel("Word Count: ");
		
		
		
		jButton.addActionListener(this);


		cp.add(label1);
		cp.add(jTextField1);
		cp.add(jButton);
		cp.add(label2);
		cp.add(jTextField2);

		
		frame.setSize(400, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getSource() == jButton) 
		{
			
			try {
				File inputfile = new File(jTextField1.getText());
				Scanner in = new Scanner(inputfile);
				int letterCount = 0;

		        while (in.hasNext())
			   {
			     String value = in.next();

				     for(int i=0;i<value.length();i++)
				     {
				     	char ch = value.charAt(i);
				     	letterCount++;
				     }	     
				     jTextField2.setText("The number of words is " + letterCount);
			    }
			} catch (FileNotFoundException e1) {
			
				e1.printStackTrace();
				
			}
		}
		
	
	
	
	}
}
