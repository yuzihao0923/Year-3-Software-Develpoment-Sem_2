package Ex9;

import java.io.FileNotFoundException;

import Ex8.replace_lines;

public class Test {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		application myapplication = new application();
	}

}
