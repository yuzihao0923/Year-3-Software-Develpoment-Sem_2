package Ex10;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Overall implements ActionListener {

	JButton jButton = new JButton("Select File");
	JTextField jTextField1 = new JTextField(20);
	JTextField jTextField2 = new JTextField(20);

	
	public Overall() {
		JFrame frame = new JFrame();
		frame.setTitle("JFrame Example");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		
		JLabel label1 = new JLabel("Keyword: ");
		JLabel label2 = new JLabel("Result: ");
		
		
		
		jButton.addActionListener(this);


		cp.add(label1);
		cp.add(jTextField1);
		cp.add(jButton);
		cp.add(label2);
		cp.add(jTextField2);

		
		frame.setSize(400, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == jButton) 
		{
			int count = 0;
			try {
				JFileChooser chooser = new JFileChooser();
				Scanner in = null;
			//	String value = in.next();
				
				if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
					{
					  File selectedFile = chooser.getSelectedFile();
					  in = new Scanner(selectedFile);
					  
					  while (in.hasNext())
					   {
					     String value = in.next();
					     if(value.equals(jTextField1.getText()))
					     {
					    	 count++;
					  
					     }
						jTextField2.setText("" + count);   
					   }
					}
			}
					catch (FileNotFoundException e1) {
				    	   e1.printStackTrace();
			      }
		}
	}
}
