package Ex1;

import java.io.FileNotFoundException;

public class Test {

	public static void main(String[] args) throws FileNotFoundException{
		// TODO Auto-generated method stub
		Average_double myAverage_double = new Average_double();
	}

}
