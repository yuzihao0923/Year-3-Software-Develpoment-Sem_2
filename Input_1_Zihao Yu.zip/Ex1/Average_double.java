package Ex1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Average_double {

	public Average_double() throws FileNotFoundException{
		
		
			// Prompt for the input and output file names
					Scanner console = new Scanner(System.in); 
					
					// SETUP to read the file
					System.out.print("Input file: ");
					String inputFileName = console.next(); 
					File inputFile = new File(inputFileName); 	
					Scanner in = new Scanner(inputFile); 
					
					// Creates an new output file 
					System.out.print("Output file: "); 
					String outputFileName = console.next();
					PrintWriter out = new PrintWriter(outputFileName);
					

					// Read the input and write the output
					double total = 0;
					int count = 0;
					double average = 0;

					while (in.hasNextDouble()) 
					{ 
						
						double value = in.nextDouble(); 
						out.println(value); 
						total = total + value;
						count++;
						
					}
					average = total/count;
					
					out.println("The Average is: " + average);
					in.close();
					out.close(); 
					console.close();
				
	}
	
}
